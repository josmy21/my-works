import { Component, OnInit } from '@angular/core';
import {AuthenticationService, User} from '../authentication.service';

@Component({
  selector: 'app-login',
  providers: [AuthenticationService],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
   private user = new User('','');
    private errorMsg = '';
  

  constructor(public myservice:AuthenticationService) {


   }
   hi() {
   console.log("hi");
    this.myservice.hiname();
  }

login() {
     
    if(!this.myservice.login(this.user)){
            this.errorMsg = 'Failed to login';
        }    }


  ngOnInit() {


  }

}
