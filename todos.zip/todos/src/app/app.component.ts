import { Component } from '@angular/core';
import {AuthenticationService, User} from './authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [AuthenticationService]
})

export class AppComponent {

  title = 'MY APP';
   constructor(public myservice:AuthenticationService) {


   }
     getname() {
    return this.myservice.get();
  }
}
