import { Component, OnInit,Input } from '@angular/core';
import {Router} from '@angular/router';



@Component({
  selector: 'app-works',
  templateUrl: './works.component.html',
  styleUrls: ['./works.component.css']
})
export class WorksComponent implements OnInit {

@Input() dataimg;

   selectedImage;

   
 
   setSelectedImage(image){
      this.selectedImage= image;  
      alert(image.src);
     
   }

id="ID";
wname="NAME";
lang="PROGRAMMING LANGUAGE";
works:any[]=[
{
	"id":1,
	"name":"smart space",
	"lang":".net"

},
{
	
	"id":2,
	"name":"alt space",
	"lang":"java"
}]
  constructor() { }

  ngOnInit() {
  }

   
submit= function () {
alert("submitted");

}

logout= function () {
alert("successfully logged  Out");
}
}


