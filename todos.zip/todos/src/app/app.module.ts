import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { WorksComponent } from './works/works.component';
import { LoginComponent } from './login/login.component';

const r = [
  { path: '',
    component: LoginComponent,
    pathMatch: 'full'
   },

  { path: 'login', component: LoginComponent,
     
  },
  { path: 'work',
    component: WorksComponent
   }
];

@NgModule({
  declarations: [
    AppComponent,
    WorksComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(r)
  ],
  providers: [],
  bootstrap:[AppComponent]
  })
export class AppModule { }
