import { Injectable } from '@angular/core';

import {Router} from '@angular/router';

export class User {
 
  constructor(public email: string, public password: string) { }

}
 
var admin =new User('jos@gmail.com','jos')



@Injectable()
export class AuthenticationService {


  constructor( public myrouter: Router) { }
  public lgname ="kkk";
  get() {
    return this.lgname;
  }
  hiname() {
   this.lgname='hi'  ;
  }
  helloname(){
   this.lgname='hello';
  }
 login(user){

   
    if ( admin.password === user.password && admin.email=== user.email){
      
      this.myrouter.navigate(['work']);   

      return true;
    }
    return false;
 
  }


}
