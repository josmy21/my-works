import { MytodoappPage } from './app.po';

describe('mytodoapp App', () => {
  let page: MytodoappPage;

  beforeEach(() => {
    page = new MytodoappPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
