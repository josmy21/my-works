import { Injectable } from '@angular/core';

@Injectable()
export class NameService {
  public count = 0;

  constructor() { }
  
    public name: string[]=['hh','kk','ll'];
   get() {

    return this.name;
  }
 
  hiname() {
    this.name.push('hi');
  }
  helloname() {
    this.name.push('hello');
  }

}
