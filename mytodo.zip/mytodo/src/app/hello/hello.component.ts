import { Component, OnInit } from '@angular/core';
import { NameService }      from '../name.service';

@Component({
  selector: 'app-hello',
  providers: [NameService],
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css']
})
export class HelloComponent implements OnInit {

  constructor(private nameService: NameService) { }

  ngOnInit() {
  }

 
names=this.nameService.get();
helloName(){
  this.nameService.helloname();
  }

}
