import { Component, OnInit } from '@angular/core';
import { NameService }      from '../name.service';
@Component({
  selector: 'app-hi',
  providers: [NameService],
  templateUrl: './hi.component.html',
  styleUrls: ['./hi.component.css'],
  
})
export class HiComponent implements OnInit {

  constructor(private nameService: NameService) { }

  ngOnInit() {
  }

 
names=this.nameService.get();

    hiName(){
  this.nameService.hiname();
  }

}
