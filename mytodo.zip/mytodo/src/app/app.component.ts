import { Component } from '@angular/core';
import { NameService }      from './name.service';


@Component({
  selector: 'app-root',
 
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
constructor(private nameService: NameService) {
   
  }
  
  title = 'app works!';
 names=this.nameService.get();
  
}
