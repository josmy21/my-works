import { Component, OnInit } from '@angular/core';
import { LoadjsonService } from '../loadjson.service';
import { RssfeedService } from '../rssfeed.service'
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [LoadjsonService,RssfeedService]
})
export class HomeComponent implements OnInit {
 json=[];
 rss=[];
 val:any;
 value:any;



  constructor(private jsonservice: LoadjsonService,private rss_service:RssfeedService ) { }

  ngOnInit() {

    this.jsonservice.getJson().subscribe(data => {
    

  for (let key in data) 
  {
       this.value = data[key];
       for(let ke in this.value)
     {
        this. val = this.value[ke];
        this.json.push(this.val)

    }
}
        console.log(this.json);





  });

  this.rss_service.getRss().subscribe(data => {
  for (let key in data) 
  {
     this.rss = data[key];
       console.log(this.rss);
       }
  
});




  }




}
