import { Injectable } from '@angular/core';
import {Todo} from './todo';

@Injectable()
export class TodoDataService {
  lastid:number=0;
  todoarr:Todo[]=[];

  constructor() { }
  AddTododata(td:Todo):TodoDataService{
 
   this.todoarr.push(td);
   return this;
  }
  getAllTodos(): Todo[] {
    return this.todoarr;
  }
}
